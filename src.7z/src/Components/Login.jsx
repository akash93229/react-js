import { useState } from "react";
import { NavLink } from "react-router-dom";
import "./Login.css";

const Login = () => {

    const [user, setUser] = useState([]);



    const loginSubmit = (e) => {

    }
    const loginInput = () => {

    }

    return (<>
        <section>
            <div className="register-main">
                <div className="register-card">
                    <h1 className="register-heading">Login Now</h1>

                    <form onSubmit={loginSubmit} action="">
                        <div className="register-form">

                            <label className="label-box" htmlFor="">email : </label>
                            <input name="email" onChange={loginInput} className="input-box" type="email" placeholder="Enter your email" />
<br/>
                            <label className="label-box" htmlFor="">Password : </label>
                            <input name="password" onChange={loginInput} className="input-box" type="password" placeholder="Create password" />

                        </div>
                        <button className="submit-btn"> <NavLink to="/menu">Submit</NavLink></button>
                       
                    </form>
                </div>
            </div>
        </section>
    </>)
};

export default Login;